class Student {
    private var name:String = "Vanya";
    var goOn:Boolean=true;
    private var cofee = Cofee();
    private  var tea = Tea();
    private  var sugar = Sugar();
    private  var cup = Cup();
    private var milk = Milk();
    private var teapot = Teapot();

    public fun GetName(): String {
        return name;
    }
    public fun SetName(name:String)
    {
        this.name = name;
    }
    public fun MakeCofee() // Создание кофе
    {
        while(goOn) {
            println(
                "Выбери что хочешь добавить:\n" + "1.Кофе\n" + "2.Сахар\n" + "3.Молоко\n" + "4.Далее\n"
            )
            when (readLine().toString().toInt()) {
                1 -> {
                    SprinkInCup(cofee)
                }

                2 -> {
                    SprinkInCup(sugar)
                }

                3 -> {
                    SprinkInCup(milk)
                    println("Вы добавили молоко!")
                }

                4 -> {
                    goOn = false;
                }

            }
        }
            println(
                "Залить водой?:\n"+"1.Да\n"+"2.Нет\n"
            )
            when(readLine().toString().toInt())
            {
                1->{
                    println("Для этого вы наполняете чайник водой")
                    teapot.SetCup(cup)
                    teapot.PourWater()
                    goOn=false;

                }
                2->{
                    println("Без воды кофе не приготовишь");
                    goOn=false;
                }
                3->{
                    goOn=false;
                }

            }
    }

    public fun MakeTea() // Создание чая
    {
        while(goOn) {
            println(
                "Выбери что хочешь добавить:\n" + "1.Чай\n" + "2.Сахар\n" + "3.Молоко\n" + "4.Далее\n"
            )
            when (readLine().toString().toInt()) {
                1 -> {
                    SprinkInCup(tea)
                }

                2 -> {
                    SprinkInCup(sugar)
                }

                3 -> {
                    SprinkInCup(milk);
                }

                4 -> {
                    goOn = false;
                }

            }
        }
            println(
                "Залить водой?:\n"+"1.Да\n"+"2.Нет\n"
            )
            when(readLine().toString().toInt())
            {
                1->{
                    println("Для этого вы наполняете чайник водой")
                    teapot.SetCup(cup)
                    teapot.PourWater()
                    goOn=false;

                }
                2->{
                    println("Без воды чай не приготовишь");
                    goOn=false;
                }
                3->{
                    goOn=false;
                }

            }
    }

    private fun SprinkInCup(abstractObject: AbstractObject)
    {
        if(abstractObject is Granular)
        {
            abstractObject.Sprink(cup);
            cup.WriteAddedObjects();
        }
        if(abstractObject is Milk)
        {
            cup.IsMilk()
        }
    }







}