class Teapot : AbstractObject() {
    override var name = "Teapot"
     override var mass = 500;
    private var volume = 750;
    private  var tempreture:Int = 24;
    private var cup = Cup()


    public fun Pour()
    {
    cup.PourWater()
    }
    public fun PourWater()
    {
        println("Подогревате воду")
        Heat();
    }
    public fun Heat()
    {

        ChangeTempreture(100);
        println("Температура воды в чайнике: "+tempreture+". Чайник кипит!")
        Pour()
    }
    private fun ChangeTempreture(tempreture: Int)
    {
        this.tempreture = tempreture;
    }

    public fun SetCup(cup: Cup)
    {
        this.cup = cup;
    }
}