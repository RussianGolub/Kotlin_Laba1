class Milk : AbstractObject() {
    override var mass = 15;
    override var name = "Milk"
}