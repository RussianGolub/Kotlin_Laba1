abstract class AbstractObject {
    abstract var mass:Int
    abstract var name:String;
    fun GetName():String
    {
        return name
    }
}
