class Tea : Granular(){
    private var sort:String = "0";
    override var mass = 10;
    override var name = "Tea"

}