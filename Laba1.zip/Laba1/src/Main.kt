fun main (){
    val menu = Menu() // создание объекта класса меню
    menu.Menu() // вызов метода меню
}
