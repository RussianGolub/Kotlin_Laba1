class Cup : AbstractObject() {
    override var name = "Сup"
    private var objectsIn: Array<Granular?>
    override var mass = 200
    private var volume = 250
    private var isMilk: Boolean = false
    private var isTea: Boolean = false
    private var isCofee: Boolean = false

    init {
        objectsIn = Array(5) { null }
    }

    public fun AddObjectIn(objectToAdd: Granular) {
        for (i in objectsIn.indices) {
            if (objectsIn[i] == null ) {
                objectsIn[i] = objectToAdd
                if(objectToAdd is Tea)
                {
                    isCofee = true
                }else if(objectToAdd is Cofee)
                {
                    isCofee = true
                }
                break
            }
        }
    }
    public fun WriteAddedObjects()
    {
        println("Добавленные продукты:")
        for (obj in objectsIn)
        {
            if (obj != null) {
                println(obj.GetName())
            };
        }
        if(isMilk) println("Молоко ")
    }
    public fun PourWater() {
        print("Вы сделали ")
        if(isCofee)
        {
            print("кофе ")
        }else if (isTea)
        {
            print("чай ")
        }else{
            print("напиток ")
        }
        if(isMilk) println("с молоком ")
        println()
        WriteAddedObjects()
    }

    public fun IsMilk()
    {
        isMilk = true
        WriteAddedObjects()
    }
}