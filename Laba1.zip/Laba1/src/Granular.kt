 open class Granular : AbstractObject(){
    override var mass:Int=0;
     override var name = "Hello";
     open fun Sprink(cup: Cup) {
         cup.AddObjectIn(this)
     }

}