class Menu {
    fun Menu()
    {
        println("Студент, введите ваше имя:") // Установка имени студента
        val student = Student();
        student.SetName(readLine().toString())
        println("Привет "+student.GetName())

        var goOn:Boolean=true;

            println(
                "Выбери что хочешь сделать:\n"+"1.Сделать Кофе\n"+"2.Сделать Чай\n"+"3.Выйти\n" // Выбор действия
            )
            when(readLine().toString().toInt())
            {
                1->{
                    student.MakeCofee();
                }
                2->{
                    student.MakeTea();
                }
                3->{
                    goOn=false;
                }

            }

        }
    }
