class Sugar: Granular() {
    override var mass = 15;
    override var name = "Sugar"
}