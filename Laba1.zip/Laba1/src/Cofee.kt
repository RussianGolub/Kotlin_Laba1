class Cofee : Granular(){
    private lateinit var taste: String;
    override var mass = 20;
    override var name = "Cofee"

}